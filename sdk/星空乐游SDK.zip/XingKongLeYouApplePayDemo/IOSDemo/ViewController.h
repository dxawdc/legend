//
//  ViewController.h
//  IOSDemo
//
//  Created by 雪鲤鱼 on 15/6/29.
//  Copyright (c) 2015年 yijie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <YijieAdvPlatform/XingKongLeYouSDKHelper.h>

@interface ViewController : UIViewController<XingKongLeYouSDKHelperLoginDelegate>

- (IBAction)initClick:(id)sender;
- (IBAction)loginClick:(id)sender;
-(void) extend;
@end

