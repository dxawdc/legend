//
//  ChargeInputController.h
//  IOSDemo
//
//  Created by 雪鲤鱼 on 15/7/17.
//  Copyright (c) 2015年 yijie. All rights reserved.
//

#import <UIKit/UIKit.h>
 
@interface RoleInputController : UIViewController
- (IBAction) cancelBtnClick:(id)sender;
- (IBAction) sureBtnClick:(id)sender;
//- (void) setChargeDelegate
@end
