//
//  ChargeInputController.m
//  IOSDemo
//
//  Created by 雪鲤鱼 on 15/7/17.
//  Copyright (c) 2015年 yijie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ChargeInputController.h"
@interface ChargeInputController ()

@end

@implementation ChargeInputController
UITextField* priceField;
UITextField* itemName;

- (IBAction)priceTextField:(UITextField *)sender {
    priceField = sender;
}
- (IBAction)itemNameTextField:(UITextField *)sender {
    itemName = sender;
}

- (IBAction) cancelBtnClick:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction) sureBtnClick:(id)sender {
    UIViewController* payController = [[self storyboard] instantiateViewControllerWithIdentifier: @"PayingViewController"];
    if (priceField != nil && itemName != nil)
        [YiJieOnlineHelper charge: itemName.text :100 :1 : nil : nil :payController];
}

@end